from ruckus_cloud import RuckusCloud


def main():
    # RuckusCloud().requests_session_example()   # Example of using a requests session

    client = RuckusCloud()
    client.examples()                            # Example of various API calls


if __name__ == "__main__":
    main()
