from __future__ import print_function

import random
import string
from datetime import datetime
from pprint import pprint
from time import sleep

import requests

from ruckus_cloud_tenant import ApiClient, TenantApi, VenueApi, RequestApi, FloorPlanApi, FileApi, AuthenticationApi, \
    UserProfileApi
from ruckus_cloud_tenant import Credentials, Request, Venue, Address, FloorPlan, UploadUrlRequest, Configuration
from ruckus_cloud_tenant.rest import ApiException
from ruckus_cloud_wifi import ApiClient as WifiApiClient, APApi as WifiAPApi, VenueApi as WifiVenueApi,  \
    NetworkApi, NetworkVenueApi
from ruckus_cloud_wifi import AP, APRadioCustomization, APRadioParams24G, APRadioParams50G, Mesh, PskNetwork, PskWlan, \
    NetworkVenue, NetworkVenueScheduler, APPosition


# Global params
username = 'YOUR_RUCKUS_CLOUD_USERNAME'
password = 'YOUR_RUCKUS_CLOUD_PASSWORD'
tenant_id = 'YOUR_RUCKUS_CLOUD_TENANT_ID'
username = 'nadav.kehati@ruckuswireless.com'
password = 'Spring20'
tenant_id = 'e7b122f9f9c34cb59eb416abeeb9297f'
floor_plan_image = r'floor-plan.jpg'


# TODO: Use logger instead of print/pprint

class RuckusCloud:

    def __init__(self):
        self.unique_text = datetime.now().strftime('%y-%m-%d %H:%M:%S')         # used to generate unique names for various entities
        self.configuration = Configuration()

        api_key = self.login()                                # Login returns api_key token
        self.auth_cookie = 'API-KEY=' + api_key               # Need to save the api_key as a cookie
        self.api_client = ApiClient(self.configuration, cookie=self.auth_cookie)            # Save cookie to APIClient
        self.wifi_api_client = WifiApiClient(self.configuration, cookie=self.auth_cookie)   # Save cookie to APIClient

    def login(self):
        # create an instance of the API class
        api_auth_client = ApiClient(self.configuration)

        auth_api = AuthenticationApi(api_auth_client)
        print('\nAPI-KEY:')
        token = auth_api.get_access_token(Credentials(username=username, password=password))
        pprint(token)
        return token.token      # will be deprecated from v20.03.xx
        #return token.api_key   # will be supported from v20.02.11

    def wait_for_async_response(self, http_info_response, sleep_time=2):
        """
        Ruckus Cloud write-APIs can be asynchronous (note: read-APIs are always synchronous).
        A response of 202 indicates an asynchronous response, in which case this function polls the request status
        until it completes.
        Any other response indicates a synchronous response.
        :param http_info_response: All Ruckus write-APIs include the request_id in the response
        :param sleep_time: Duration to wait between polling the status
        :return: The original API response
        """

        api_response = http_info_response[0]
        http_response = http_info_response[1]
        if http_response != 202:                # 202 "accepted" indicates that this is an async call
            return api_response.response

        request_id = api_response.request_id
        print('\nrequest_id:', request_id)
        request_api = RequestApi(self.api_client)

        # Retrieve all pending requests (not needed for flow; just an example)
        pendings = request_api.get_requests_by_status(tenant_id, "PENDING")
        print('\nPENDING:')
        pprint(pendings)

        # Loop while our request is pending
        request_details = Request(status='PENDING')                 # Set to "PENDING" to enter the loop
        while request_details.status not in ['SUCCESS', 'FAIL']:
            request_details = request_api.get_request(tenant_id, request_id)
            print('\nrequest:', request_details)

            sleep(sleep_time)

        if request_details.status != 'SUCCESS':
            raise Exception(request_details.status)

        return api_response.response

    def download_file(self, file_id):
        """
        Downloading a file is different from other APIs, as the call redirects to a file store API which will fail if headers are present
        :param file_id: As returned by the download-url API
        :return: None (the downloaded content is saved as a file)
        """
        print('Download file:', file_id)
        r = requests.get(                       # This returns a redirect to the actual file location
            self.configuration.host + '/api/file/tenant/' + tenant_id + '/' + file_id,
            cookies=dict((self.api_client.cookie.split('='),)),       # requests expects cookie dictionary
            headers={'content-type': 'application/json', 'accept': 'application/json'},
            allow_redirects=False)
        pprint(r)
        # The redirected location will fail if it includes headers from the original request above
        while r.status_code == 302:
            print('Redirected to:', r.headers['location'])
            r = requests.get(r.headers['location'])         # send redirect requests without headers
            pprint(r)
        if r.status_code == 200:
            open(file_id, 'wb').write(r.content)

    def examples(self):
        """
        Examples of calling various Ruckus Cloud APIs.
        In general we will create a venue, include a floor-plan, add an AP, and create & associated a network
        """
        try:
            tenant_api = TenantApi(self.api_client)

            # Get Tenant Details
            print('\ntenant:')
            tenant = tenant_api.get_tenant(tenant_id)
            pprint(tenant)
            print('\nAccount details:')
            api_response = tenant_api.get_account_details(tenant_id)
            pprint(api_response)

            print('\nUser profile:')
            user_profile_api = UserProfileApi(self.api_client)
            api_response = user_profile_api.get_user(tenant_id)
            pprint(api_response)

            # Create Venue
            venue_api = VenueApi(self.api_client)
            print('\nCreating venue:', 'Example ' + self.unique_text)
            venue = Venue(
                address=Address(address_line='350 W Java Dr', city='Sunnyvale, California', country='United States',
                                timezone='America/Los_Angeles'),
                description='Example Venue',
                floor_plans=None,
                name='Example ' + self.unique_text)
            venue = self.wait_for_async_response(venue_api.create_venue_with_http_info(tenant_id, venue))
            print('Venue response:')
            pprint(venue)
            venue_id = venue.id
            print('Venue ID:', venue_id)

            floor_plan = None
            if floor_plan_image:
                # Upload a file to be used as the floor-plan image
                file_api = FileApi(self.api_client)
                print('Get File Upload Url:')
                upload_details = file_api.get_upload_url(tenant_id, UploadUrlRequest(file_extension='jpg'))
                pprint(upload_details)
                r = requests.put(upload_details.signed_url, data=open(floor_plan_image, 'rb'))
                pprint(r)

                # Download file (not needed for flow; just an example how to download a previously uploaded file)
                self.download_file(upload_details.file_id)

                # Create floor-plan
                floor_plan_api = FloorPlanApi(self.api_client)
                print('\nFloor-plan:')
                floor_plan = FloorPlan(name="FirstFloor",
                                       floor_number=1,
                                       image_id=upload_details.file_id)
                pprint(floor_plan)
                floor_plan = self.wait_for_async_response(
                    floor_plan_api.create_venue_floor_plan_with_http_info(tenant_id, venue_id, floor_plan))
                pprint(floor_plan)
                # Associate the floor-plan with the venue
                venue.floor_plans = [floor_plan]
                print('\nUpdating venue with floor-plan:')
                venue = self.wait_for_async_response(venue_api.update_venue_with_http_info(tenant_id, venue_id, venue))
                pprint(venue)

            # Iterate over the list of venues (not needed for flow; just as an example)
            print('\nvenues:')
            venues = venue_api.get_venues(tenant_id)
            pprint(venues)
            for venue in venues:
                id = venue.id
                print('\nvenue:', id)
                v = venue_api.get_venue(tenant_id, id)
                pprint(v)

            # Call Wifi-APIs
            # Note the use of wifi_api_client (instead of api_client) for wifi-APIs
            wifi_venue_api = WifiVenueApi(self.wifi_api_client)
            print('\nSet wifi-venue mesh:')
            wifi_venue = self.wait_for_async_response(wifi_venue_api.update_mesh_with_http_info(tenant_id, venue_id, Mesh(enabled=True)))
            pprint(wifi_venue)

            # Iterate over the list of aps (not needed for flow; just as an example)
            print('\nwifi aps:')
            wifi_ap_api = WifiAPApi(self.wifi_api_client)
            aps = wifi_ap_api.get_aps(tenant_id)
            pprint(aps)
            for ap in aps:
                id = ap.serial_number
                print('\nwifi ap:', id)
                ap_details = wifi_ap_api.get_ap(tenant_id, id)  # getting a specific AP also returns operational data
                pprint(ap_details)

                # Delete the AP
                # api_response = wifi_ap_api.delete_ap(tenant, id)
                # print('\ndelete wifi ap response:')
                # pprint(api_response)
                # response_status = self.wait_for_response_status(api_response.request_id)
                # print('\ndelete wifi ap response status:', response_status)

            # Add AP
            serial_number = '1' + ''.join(
                random.choice(string.digits) for i in range(11))  # serial-number cannot start with '0'
            position = None
            if floor_plan:
                position = APPosition(floorplan_id=floor_plan.id, x_percent=25, y_percent=75)
            print('\nserial_number:', serial_number)
            ap = AP(
                ap_group_id=None,
                description="Description" + self.unique_text,
                name='AP-' + self.unique_text,
                position=position,
                serial_number=serial_number,
                tags=['Test'],
                venue_id=venue_id)
            new_ap = self.wait_for_async_response(wifi_ap_api.add_aps_with_http_info(tenant_id, [ap]))
            print('\nadd wifi ap response:')
            pprint(new_ap)

            # Update AP Position
            if floor_plan:
                new_ap = self.wait_for_async_response(wifi_ap_api.update_ap_position_with_http_info(tenant_id, ap.serial_number, {'floorplanId': floor_plan.id, 'xPercent': 50, 'yPercent': 50}))
                print('\nupdate wifi ap position response:')
                pprint(new_ap)

            # Set AP Radio
            radio = APRadioCustomization(
                ap_radio_params24_g=APRadioParams24G(allowed_channels=None,
                                                     change_interval=480,
                                                     channel_bandwidth='AUTO',
                                                     manual_channel=None,
                                                     method='BACKGROUND_SCANNING',
                                                     operative_channel=None,
                                                     operative_tx_power=None,
                                                     snr_d_b=None,
                                                     tx_power='MAX'),
                ap_radio_params50_g=APRadioParams50G(allowed_channels=None,
                                                     change_interval=480,
                                                     channel_bandwidth='AUTO',
                                                     manual_channel=None,
                                                     method='BACKGROUND_SCANNING',
                                                     operative_channel=None,
                                                     operative_tx_power=None,
                                                     snr_d_b=None,
                                                     tx_power='MAX'),
                enable24_g=True,
                enable50_g=True,
                use_venue_settings=False
            )

            print('\nupdate wifi ap radio response:')
            try:
                radio = self.wait_for_async_response(
                    wifi_ap_api.update_ap_radio_with_http_info(tenant_id, serial_number, radio))
                pprint(radio)
            except Exception as e:
                print("Can only set radio after AP is operational")

            # Create Network
            network_api = NetworkApi(self.wifi_api_client)
            print('\nCreating network:')
            network = PskNetwork(
                name='Example ' + self.unique_text,
                description='Example Network',
                type="psk",         # Ideally this would be set automatically by PskNetwork class
                wlan=PskWlan(
                    advanced_customization=None,
                    enabled=True,
                    passphrase='MySecretPassphrase',
                    ssid='Example ' + self.unique_text,
                    vlan_id=1,
                    wlan_security='WPA2Personal'
                ))
            network = self.wait_for_async_response(network_api.create_network_with_http_info(tenant_id, network))
            print('Network response:')
            pprint(network)
            network_id = network.id
            print('Network ID:', network_id)

            network_venue_api = NetworkVenueApi(self.wifi_api_client)
            print('\nAssociating network:', network_id, venue_id)
            network_venue = NetworkVenue(
                all_ap_groups_radio='Both',
                all_ap_groups_vlan_id=None,
                ap_groups=[],
                is_all_ap_groups=True,
                network_id=network_id,
                scheduler=NetworkVenueScheduler(),
                venue_id=venue_id
            )
            network_venue = self.wait_for_async_response(network_venue_api.create_network_venue_with_http_info(tenant_id, network_venue))
            print('NetworkVenue response:')
            pprint(network_venue)
            network_venue_id = network_venue.id
            print('NetworkVenue ID:', network_venue_id)

        except ApiException as e:
            print("Exception when calling API: %s\n" % e)
        except Exception as e:
            print("Exception when calling API: %s\n" % e)

    @staticmethod
    def requests_session_example():
        """
        Example of using a requests session, using the cookie returned by the /token API (supported from v200211))
        """

        # Use a session to save the authentication cookie between API calls - supported from v200211.
        s = requests.Session()

        # Obtain authentication cookie (cookie is saved to the session)
        r = s.post('https://ruckus.cloud/token', json={'username': username, 'password': password})
        print('token:', r)

        # Call arbitrary API
        r = s.get('https://ruckus.cloud/api/tenant/' + tenant_id)
        print('tenant:', r.json())
